open OUnit2
open Poker
open Card
open Deck
open Print
open Hole

(** [card_suit_test name card expected_output] constructs an OUnit test named
    [name] that asserts the quality of [expected_output] with [get_suit card]. *)
let card_suit_test (name : string) (card : Card.t) (expected_output : char) :
    test =
  name >:: fun _ -> assert_equal expected_output (get_suit card)

(** [card_num_test name card expected_output] constructs an OUnit test named
    [name] that asserts the quality of [expected_output] with [get_num card]. *)
let card_num_test (name : string) (card : Card.t) (expected_output : int) : test
    =
  name >:: fun _ -> assert_equal expected_output (get_num card)

(** [card_str_test name card expected_output] constructs an OUnit test named
    [name] that asserts the quality of [expected_output] with [str_card card]. *)
let card_str_test (name : string) (card : Card.t) (expected_output : string) :
    test =
  name >:: fun _ -> assert_equal expected_output (str_card card)

let card_tests =
  [
    card_suit_test "Hearts suit" (make_card 1 'H') 'H';
    card_suit_test "Spades suit" (make_card 1 'S') 'S';
    card_suit_test "Clubs suit" (make_card 1 'C') 'C';
    card_suit_test "Diamonds suit" (make_card 1 'D') 'D';
    card_num_test "Ace number" (make_card 1 'H') 1;
    card_num_test "7 number" (make_card 7 'H') 7;
    card_num_test "Jack number" (make_card 11 'H') 11;
    card_num_test "King number" (make_card 12 'H') 12;
    card_num_test "Queen number" (make_card 13 'H') 13;
    card_str_test "Queen of Hearts" (make_card 12 'H') "Queen of Hearts";
    card_str_test "Ace of Spades" (make_card 1 'S') "Ace of Spades";
    card_str_test "Seven of Clubs" (make_card 7 'C') "7 of Clubs";
    card_str_test "Ten of Diamonds" (make_card 10 'D') "10 of Diamonds";
    ( "make_card raises IllegalSuit" >:: fun _ ->
      assert_raises IllegalSuit (fun () -> make_card 10 'F') );
    ( "make_card raises IllegalSuit" >:: fun _ ->
      assert_raises IllegalSuit (fun () -> make_card 10 'd') );
    ( "make_card raises IllegalNum" >:: fun _ ->
      assert_raises IllegalNum (fun () -> make_card 0 'D') );
    ( "make_card raises IllegalNum" >:: fun _ ->
      assert_raises IllegalNum (fun () -> make_card 17 'D') );
    ( "make_card raises IllegalNum" >:: fun _ ->
      assert_raises IllegalNum (fun () -> make_card ~-3 'D') );
  ]

(** [deck_size_test name deck expected_output] constructs an OUnit test named
    [name] that asserts the quality of [expected_output] with [get_size deck]. *)
let deck_size_test (name : string) (deck : Deck.t) (expected_output : int) :
    test =
  name >:: fun _ -> assert_equal expected_output (get_size deck)

let (deck : Deck.t) = init_deck

let deck_tests =
  [
    deck_size_test "Full deck" deck 52;
    deck_size_test "minus S1" (remove_card deck (make_card 1 'S')) 51;
    deck_size_test "get_cards size" deck (List.length (get_cards deck));
  ]

(** [pair_test name hole] constructs an OUnit test named [name] that asserts the
    quality of the cards in hole [hole] with [is_pair hole]. *)
let pair_test (name : string) (hole : Hole.t) : test =
  name >:: fun _ ->
  assert_equal
    (get_num (get_first hole) = get_num (get_second hole))
    (is_pair hole)

let hole_tests = [ pair_test "random hole" (make_hole init_deck) ]

let suite =
  "test suite for final project"
  >::: List.flatten [ card_tests; deck_tests; hole_tests ]

let _ = run_test_tt_main suite
