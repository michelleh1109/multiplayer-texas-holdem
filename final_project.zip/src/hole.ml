type t = Card.t * Card.t

exception IllegalHole

let make_hole deck =
  let size = Deck.get_size deck in
  let h1 = List.nth (Deck.get_cards deck) (Random.int size) in
  let deck1 = Deck.remove_card deck h1 in
  let size1 = Deck.get_size deck1 in
  let h2 = List.nth (Deck.get_cards deck1) (Random.int size1) in
  (h1, h2)

let get_first t =
  match t with
  | a, b -> a

let get_second t =
  match t with
  | a, b -> b

let is_pair t =
  let h1 = get_first t in
  let h2 = get_second t in
  if Card.get_num h1 = Card.get_num h2 then true else false
