type t = int * char

exception IllegalSuit
exception IllegalNum

(** [check_num n] returns [n] if it is a valid number (from 1 and 13). Raises:
    IllegalNum if [n] is not a valid number*)
let check_num n = if n >= 1 && n <= 13 then n else raise IllegalNum

(** [check_suit s] returns [s] if it is a valid suit (either S, H, D, or C).
    Raises: IllegalSuit if [s] is not a valid suit*)
let check_suit s =
  match s with
  | 'S' -> 'S'
  | 'H' -> 'H'
  | 'D' -> 'D'
  | 'C' -> 'C'
  | _ -> raise IllegalSuit

let make_card num suit = (check_num num, check_suit suit)

let get_num card =
  match card with
  | n, _ -> n

let get_suit card =
  match card with
  | _, s -> s

(** [string_num n] converts n to a string. If n represents a special card like
    Ace, Jack, Queen, or King, then n becomes the corresponding name. Otherwise,
    n is just the string version of the int*)
let string_num n =
  match n with
  | 13 -> "King"
  | 12 -> "Queen"
  | 11 -> "Jack"
  | 1 -> "Ace"
  | num -> string_of_int num

(** [string_suit s] converts n to a string. If n represents a special card like
    Ace, Jack, Queen, or King, then n becomes the corresponding name. Otherwise,
    n is just the string version of the int*)
let string_suit s =
  match s with
  | 'S' -> "Spades"
  | 'H' -> "Hearts"
  | 'D' -> "Diamonds"
  | 'C' -> "Clubs"
  | _ -> raise IllegalSuit

let str_card (n, s) = string_num n ^ " of " ^ string_suit s
