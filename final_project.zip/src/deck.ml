type t = {
  cards : Card.t list;
  size : int;
}

exception IllegalCard

let rec create_deck num =
  if num <= 13 then
    [
      Card.make_card num 'S';
      Card.make_card num 'H';
      Card.make_card num 'D';
      Card.make_card num 'C';
    ]
    @ create_deck (num + 1)
  else []

let init_deck = { cards = create_deck 1; size = 52 }
let get_cards deck = deck.cards
let get_size deck = deck.size

let remove_card deck card =
  {
    cards = List.filter (fun x -> card <> x) (get_cards deck);
    size = get_size deck - 1;
  }
